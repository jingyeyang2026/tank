package com.tedu.controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;

import com.tedu.element.ElementObj;
import com.tedu.manager.ElementManager;
import com.tedu.manager.GameElement;

/**
 * @说明 监听类，用于监听用户的操作 KeyListener
 *
 *
 */
public class GameListener implements KeyListener{
	private ElementManager em = ElementManager.getManager();

	@Override
	public void keyTyped(KeyEvent e) {
		// 键盘敲击事件，通常用不到
	}

	/**
	 * 按下: 左37 上38 右39 下40
	 * 实现主角的移动
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		// 【修复】移除了Set防抖逻辑，让长按移动可以持续触发
		int key = e.getKeyCode();
		List<ElementObj> play = em.getElementsByKey(GameElement.PLAY);
		for(ElementObj obj: play) {
			obj.keyClick(true, key);
		}
	}

	/** 松开 */
	@Override
	public void keyReleased(KeyEvent e) {
		// 【修复】移除了Set防抖逻辑
		int key = e.getKeyCode();
		List<ElementObj> play = em.getElementsByKey(GameElement.PLAY);
		for(ElementObj obj: play) {
			obj.keyClick(false, key);
		}
	}
}



