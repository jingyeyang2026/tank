package com.tedu.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import com.tedu.element.*;
import com.tedu.element.Wall;
import com.tedu.manager.CollisionChecker;
import com.tedu.manager.ElementManager;
import com.tedu.manager.GameElement;
import com.tedu.manager.GameLoad;
import com.tedu.show.GameStartFrame;

/**
 * @说明 游戏的主线程，用于控制游戏加载，游戏关卡，游戏运行时自动化
 * 游戏判定；地图切换、资源释放和重新读取等。
 *
 */
public class GameThread extends Thread {
	// 运行标记
	private volatile boolean gameRunning = true;
	private volatile boolean threadAlive = true;
	private ElementManager em;

	public GameThread() {
		em = ElementManager.getManager();
	}

	@Override
	public void run() {
		while (threadAlive) {
			// 1.循环开头清空上一关残留
			ElementManager em = ElementManager.getManager();
			em.clearAllElement();
			gameRunning = true;
			gameLoad();
			List<ElementObj> wallAll = em.getElementsByKey(GameElement.WALL);
			CollisionChecker.getInstance().refreshWallData(wallAll);
			gameRun();
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("游戏线程完全终止，退出run方法");
	}

	/**
	 * 游戏的加载
	 */
	private void gameLoad() {
		ElementManager em = ElementManager.getManager();
		System.out.println("=====进入gameLoad，开始加载关卡=====");
		try {
			GameLoad.loadObj();
			GameLoad.loadImg();
			if (GameLoad.imgMap.isEmpty()) {
				System.err.println("图片资源加载失败！");
				return;
			}
			int mapId = ElementManager.getNowLevel();
			GameLoad.MapLoad(mapId);

			int playNum = ElementManager.getPlayerCount();
			GameLoad.loadPlay(playNum);
			GameLoad.loadEnemy();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 游戏进行时
	 */
	private void gameRun() {
		long gameTime = 0L;
		gameRunning = true;
		while (gameRunning) {
			Map<GameElement, List<ElementObj>> all = em.getGameElements();
			List<ElementObj> enemys = em.getElementsByKey(GameElement.ENEMY);
			List<ElementObj> files = em.getElementsByKey(GameElement.PLAYFILE);
			List<ElementObj> maps = em.getElementsByKey(GameElement.MAPS);
			List<ElementObj> walls = em.getElementsByKey(GameElement.WALL);

			moveAndUpdate(all, gameTime);

			// 敌人被子弹打
			ElementPK(enemys, files);

			// 玩家被子弹打
			List<ElementObj> players = em.getElementsByKey(GameElement.PLAY);
			ElementPK(players, files);



			// 子弹打地图/墙体
			for (ElementObj bulletObj : files) {
				if (bulletObj.isDie()) continue;
				PlayFile bullet = (PlayFile) bulletObj;
				for (ElementObj wallObj : walls) {
					if (!wallObj.isLive()) continue;
					Wall wall = (Wall) wallObj;
					if (!wall.isAlive()) continue;
					// 矩形碰撞pk判定
					if (bullet.pk(wall)) {
						wall.breakWall();  // 墙体破碎
						bullet.setDie(true);
						break;
					}
				}
			}

			gameTime++;
			try {
				sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			checkGameResult(players, enemys);
		}
		System.out.println("当前关卡运行结束，退出gameRun循环");
	}

	/**
	 * 碰撞判定
	 * listA = 被攻击者（坦克/墙），listB = 子弹
	 */
	public void ElementPK(List<ElementObj> tankList, List<ElementObj> bulletList) {
		if (tankList == null || tankList.isEmpty() || bulletList == null || bulletList.isEmpty()) {
			return;
		}

		for (ElementObj bulletObj : bulletList) {
			if (bulletObj.isDie()) continue;
			PlayFile bullet = (PlayFile) bulletObj;



			if (bullet.getLifeTime() < 5) {
				continue;
			}

			Object shooter = bullet.getShooter();

			for (ElementObj tankObj : tankList) {
				if (tankObj.isDie()) continue;

				// 矩形碰撞检测
				if (bullet.pk(tankObj)) {

					if (tankObj == shooter) {
						continue;
					}

					// 如果不是自己，正常造成伤害
					tankObj.die();
					bullet.setDie(true);
					break; // 一颗子弹只能打一个目标
				}
			}
		}
	}

	/**
	 * 游戏元素自动化方法
	 */
	public void moveAndUpdate(Map<GameElement, List<ElementObj>> all, long gameTime) {
		for (GameElement ge : GameElement.values()) {
			if (ge == GameElement.WALL) continue;
			List<ElementObj> list = all.get(ge);
			if (list == null) continue;
			for (int i = list.size() - 1; i >= 0; i--) {
				ElementObj obj = list.get(i);
				if (obj.isDie()) {
					list.remove(i);
					continue;
				}
				obj.model(gameTime);
			}
		}
	}

	public void gameOver() {
		this.gameRunning = false;
	}

	public void stopThread() {
		this.threadAlive = false;
		this.gameRunning = false;
	}

	/**
	 * 胜负判定
	 */
	private void checkGameResult(List<ElementObj> players, List<ElementObj> enemys) {
		boolean allPlayerDead = true;
		for (ElementObj p : players) {
			if (!p.isDie()) {
				allPlayerDead = false;
				break;
			}
		}
		if (allPlayerDead) {
			System.out.println("游戏失败，全部玩家阵亡");
			this.gameRunning = false;
			return;
		}

		boolean allEnemyDead = true;
		for (ElementObj e : enemys) {
			if (!e.isDie()) {
				allEnemyDead = false;
				break;
			}
		}
		if (!allEnemyDead) return;

		int currentLevel = ElementManager.getNowLevel();
		System.out.println("关卡" + currentLevel + "通关胜利");
		this.gameRunning = false;
		if (currentLevel < 10) {
			ElementManager.setNowLevel(currentLevel + 1);
		} else {
			this.stopThread();
			SwingUtilities.invokeLater(() -> {
				GameStartFrame root = GameStartFrame.getInstance();
				root.switchToMenu();
			});
		}
	}
}






