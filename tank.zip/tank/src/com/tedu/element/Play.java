package com.tedu.element;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import com.tedu.manager.*;

public class Play extends ElementObj {
	// 玩家编号 1=玩家1(方向键+空格) 2=玩家2(WASD+G)
	private int playerNo = 1;
	private boolean left = false; // 左
	private boolean up = false;   // 上
	private boolean right = false;// 右
	private boolean down = false; // 下
	// 变量专门用来记录当前主角面向的方向,默认为是up
	private String fx = "up";
	private boolean pkType = false;// 攻击状态 true 攻击 false停止
	private final GameWindowConfig windowCfg = GameWindowConfig.getInstance();

	public Play() {}

	public Play(int x, int y, int w, int h, ImageIcon icon) {
		super(x, y, w, h, icon);
	}

	@Override
	public ElementObj createElement(String str) {
		Play play = new Play();
		String[] split = str.split(",");
		play.setX(Integer.parseInt(split[0]));
		play.setY(Integer.parseInt(split[1]));
		String dir = split[2];
		ImageIcon icon2 = GameLoad.imgMap.get(dir);
		if (icon2 == null) {
			System.err.println("警告：贴图标识 "+dir+" 不存在，使用默认坦克尺寸50*50");
			play.setW(50);
			play.setH(50);
		} else {
			play.setW(icon2.getIconWidth());
			play.setH(icon2.getIconHeight());
			play.setIcon(icon2);
		}
		play.setDie(false);
		play.setLive(true);
		play.fx = dir;
		return play;
	}

	@Override
	public void showElement(Graphics g) {
		if(this.isDie() && System.currentTimeMillis() - this.getDieTime() > 800){
			return;
		}
		if(this.getIcon() == null){
			g.setColor(Color.GREEN);
			g.fillRect(getX(), getY(), getW(), getH());
			return;
		}
		g.drawImage(this.getIcon().getImage(), this.getX(), this.getY(), this.getW(), this.getH(), null);
	}

	@Override
	public void keyClick(boolean bl, int key) {
		if(this.isDie()){
			return;
		}
		int no = this.getPlayerNo();
		if (bl) { // ============ 按键按下逻辑 ============
			if (no == 1) { // 玩家1 方向键 + 空格开火
				switch (key) {
					case 37: // 左
						this.down = false; this.up = false; this.right = false; this.left = true; this.fx = "left"; break;
					case 38: // 上
						this.right = false; this.left = false; this.down = false; this.up = true; this.fx = "up"; break;
					case 39: // 右
						this.down = false; this.up = false; this.left = false; this.right = true; this.fx = "right"; break;
					case 40: // 下
						this.right = false; this.left = false; this.up = false; this.down = true; this.fx = "down"; break;
					case 32: // 空格 开火
						this.pkType = true; break;
				}
			}
			if (no == 2) { // 玩家2 WASD + G开火
				switch (key) {
					case 65: // A 左
						this.down = false; this.up = false; this.right = false; this.left = true; this.fx = "left"; break;
					case 87: // W 上
						this.right = false; this.left = false; this.down = false; this.up = true; this.fx = "up"; break;
					case 68: // D 右
						this.down = false; this.up = false; this.left = false; this.right = true; this.fx = "right"; break;
					case 83: // S 下
						this.right = false; this.left = false; this.up = false; this.down = true; this.fx = "down"; break;
					case 71: // G 发射子弹
						this.pkType = true; break;
				}
			}
		} else { // ============ 按键松开逻辑 ============
			if (no == 1) {
				switch (key) {
					case 37: this.left = false; break;
					case 38: this.up = false; break;
					case 39: this.right = false; break;
					case 40: this.down = false; break;
					case 32: this.pkType = false; break;
				}
			}
			if (no == 2) {
				switch (key) {
					case 65: this.left = false; break;
					case 87: this.up = false; break;
					case 68: this.right = false; break;
					case 83: this.down = false; break;
					case 71: this.pkType = false; break;
				}
			}
		}
	}

	@Override
	public void move() {
		CollisionChecker checker = CollisionChecker.getInstance();
		GameWindowConfig windowCfg = GameWindowConfig.getInstance();
		int maxWidth = windowCfg.getGameWindowWidth();

		boolean canLeft = checker.canMoveLeft(this);
		boolean canUp = checker.canMoveUp(this);
		boolean canRight = checker.canMoveRight(this);
		boolean canDown = checker.canMoveDown(this);

		// 左移：窗口边界 + 墙体碰撞双重判定
		if (this.left && this.getX() > 0 && canLeft) {
			this.setX(this.getX() - 1);
		}
		if (this.up && this.getY() > 0 && canUp) {
			this.setY(this.getY() - 1);
		}
		if (this.right && (this.getX() + this.getW()) < maxWidth && canRight) {
			this.setX(this.getX() + 1);
		}
		if (this.down && this.getY() < 520 && canDown) {
			this.setY(this.getY() + 1);
		}
	}

	@Override
	protected void updateImage() {
		String key;
		// 玩家1：直接用 fx（up/down/left/right）
		if(this.playerNo == 1){
			key = this.fx ;
		}else{ // 玩家2：fx后拼接2，读取 up2/down2/left2/right2
			key = this.fx + "2";
		}
		ImageIcon icon = GameLoad.imgMap.get(key);
		if(icon != null){
			this.setIcon(icon);
		}else{
			System.err.println("玩家"+playerNo+" 贴图标识["+key+"]缺失，请检查GameData.pro配置");
		}
	}

	private long filetime = 0;

	@Override
	public void add(long gameTime) {
		if(!this.pkType) {
			return;
		}
		this.pkType = false;

		ElementObj obj = GameLoad.getObj("file");
		PlayFile bullet = (PlayFile) obj;
		ElementObj element = obj.createElement(this.toString());

		// 设置子弹发射者
		if(this.getPlayerNo() == 1){
			bullet.setShooterId(PlayFile.SHOOTER_P1);
		}else{
			bullet.setShooterId(PlayFile.SHOOTER_P2);
		}
		// 【关键修复】把当前玩家对象（this）传给子弹
		bullet.setShooter(this);

		ElementManager.getManager().addElement(element, GameElement.PLAYFILE);
	}

	@Override
	public String toString() {
		int x = this.getX();
		int y = this.getY();
		int bulletVelocity = 13;
		int bulletDist = 5;
		switch(this.fx) {
			case "up":
				x += bulletVelocity;
				y -= bulletDist;
				break;
			case "left":
				y += bulletVelocity;
				x -= bulletDist;
				break;
			case "right":
				x += (50 + bulletDist);
				y += bulletVelocity;
				break;
			case "down":
				y += (50 + bulletDist);
				x += bulletVelocity;
				break;
		}
		return "x:" + x + ",y:" + y + ",f:" + this.fx;
	}

	public int getPlayerNo() {
		return playerNo;
	}

	public void setPlayerNo(int playerNo) {
		this.playerNo = playerNo;
	}

	@Override
	public void die() {
		if(this.isDie()) return;
		super.die();
		ImageIcon dieImg = GameLoad.imgMap.get("die");
		if(dieImg != null){
			this.setIcon(dieImg);
		}else{
			System.err.println("死亡贴图die缺失，请检查GameData.pro配置");
		}
		this.setDieTime(System.currentTimeMillis());
	}
}


