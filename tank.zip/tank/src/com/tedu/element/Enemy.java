package com.tedu.element;

import com.tedu.manager.CollisionChecker;
import com.tedu.manager.ElementManager;
import com.tedu.manager.GameElement;
import com.tedu.manager.GameLoad;
import com.tedu.manager.GameWindowConfig;

import java.awt.Graphics;
import java.util.Random;

import javax.swing.ImageIcon;

public class Enemy extends ElementObj{
	//private ImageIcon dieImage = GameLoad.imgMap.get("die");
	private boolean left = false;
	private boolean right= false;
	private boolean up = false;
	private boolean down = false;

	private Random random = new Random();
	private CollisionChecker checker = CollisionChecker.getInstance();
	// 开火冷却
	private long lastFireTime = 0;
	private final long fireCd = 800;

	// 根据方向切换敌方贴图 up3/down3/left3/right3
	private void changeDirIcon() {
		String iconKey = "up3";
		if (up) {
			iconKey = "up3";
		} else if (down) {
			iconKey = "down3";
		} else if (left) {
			iconKey = "left3";
		} else if (right) {
			iconKey = "right3";
		}
		// 赋值贴图
		this.setIcon(GameLoad.imgMap.get(iconKey));
	}

	// 随机重置移动方向 + 同步切换贴图
	public void randomDir() {
		left = false;
		right = false;
		up = false;
		down = false;
		int dirNum = random.nextInt(4);
		switch (dirNum) {
			case 0:
				up = true;
				left = false;
				right = false;
				down = false;
				break;
			case 1:
				down = true;
				left = false;
				right = false;
				up = false;
				break;
			case 2:
				left = true;
				right = false;
				up = false;
				down = false;
				break;
			case 3:
				right = true;
				left = false;
				up = false;
				down = false;
				break;
		}
		// 换向立刻更新贴图
		changeDirIcon();
	}

	@Override
	public void showElement(Graphics g) {
		// 死亡判断：die=true 直接不渲染
		if(this.isDie() && System.currentTimeMillis() - this.getDieTime() > 800) return;

		if(getIcon() == null) return;
		g.drawImage(this.getIcon().getImage(), this.getX(), this.getY(), this.getW(), this.getH(), null);
	}

	@Override
	public ElementObj createElement(String str) {
		// str格式：x,y,dir  由GameLoad传入
		Enemy enemy = new Enemy();
		String[] arr = str.split(",");
		int x = Integer.parseInt(arr[0]);
		int y = Integer.parseInt(arr[1]);
		String dir = arr[2];

		enemy.setX(x);
		enemy.setY(y);
		enemy.setW(40);
		enemy.setH(40);
		enemy.setLive(true);
		// 新建实体默认存活 die=false
		enemy.setDie(false);
		// 初始化随机方向，自动加载对应贴图
		enemy.randomDir();
		return enemy;
	}

	@Override
	public void move() {
		GameWindowConfig windowCfg = GameWindowConfig.getInstance();
		int maxW = windowCfg.getGameWindowWidth();

		// 每30帧随机换一次方向
		if(random.nextInt(30) == 0) {
			randomDir();
		}

		boolean hitWall = false;
		// 左移
		if(left && getX()>0 && checker.canMoveLeft(this)){
			setX(getX()-1);
		}else if(left){
			hitWall = true;
		}
		// 上移
		if(up && getY()>0 && checker.canMoveUp(this)){
			setY(getY()-1);
		}else if(up){
			hitWall = true;
		}
		// 右移
		if(right && (getX()+getW())<maxW && checker.canMoveRight(this)){
			setX(getX()+1);
		}else if(right){
			hitWall = true;
		}
		// 下移 限制y<520
		if(down && getY()<520 && checker.canMoveDown(this)){
			setY(getY()+1);
		}else if(down){
			hitWall = true;
		}

		// 撞墙立刻更换方向，同步切换贴图
		if(hitWall) {
			randomDir();
		}
	}

	// 随机自动发射子弹
	private void autoShoot() {
		long now = System.currentTimeMillis();
		long diff = now - lastFireTime;
		System.out.println("【敌人开火检测】间隔差值：" + diff);

		// 冷却判断
		if (diff < fireCd) {
			System.out.println("冷却不足，跳过");
			return;
		}
		System.out.println("=== 满足时间，执行开火===");
		lastFireTime = now;

		// 和玩家一模一样获取子弹
		ElementObj tempBullet = GameLoad.getObj("file");
		if (tempBullet == null) {
			System.err.println("获取子弹失败：getObj(\"file\")返回null");
			return;
		}
		PlayFile bullet = (PlayFile) tempBullet;
		System.out.println("子弹实体获取成功");

		// 获取朝向，和玩家代码相同
		String dir = "up";
		if (up) dir = "up";
		else if (down) dir = "down";
		else if (left) dir = "left";
		else if (right) dir = "right";
		System.out.println("子弹方向：" + dir);

		// 坐标公式完全照搬玩家
		int bx = this.getX() + this.getW() / 2 - 4;
		int by = this.getY() + this.getH() / 2 - 4;
		System.out.println("子弹生成坐标 x:" + bx + " y:" + by);

		bullet.createElement(bx + "," + by + "," + dir);
		bullet.setShooter(this);

		ElementManager.getManager().addElement(bullet, GameElement.PLAYFILE);
		System.out.println("子弹存入PLAYFILE分组完成");
	}

	@Override
	public void add(long gameTime) {
		move();
		autoShoot();
	}

	/**
	 * 重写父类die死亡方法
	 * 1.调用父类die标记die=true
	 * 2.替换死亡贴图
	 */
	@Override
	public void die() {
		if(this.isDie()) return;
		// 调用父类，统一设置die=true
		super.die();
		// 切换为死亡图片
		ImageIcon dieImg = GameLoad.imgMap.get("die");
		if(dieImg != null){
			this.setIcon(dieImg);
			System.out.println("成功切换死亡贴图");
		}else{
			System.err.println("死亡贴图die缺失，请检查GameData.pro配置");
		}
		this.setDieTime(System.currentTimeMillis());
	}
}