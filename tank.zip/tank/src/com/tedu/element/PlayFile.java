package com.tedu.element;

import java.awt.Color;
import java.awt.Graphics;
import java.util.List;

import javax.swing.ImageIcon;

import com.tedu.manager.ElementManager;
import com.tedu.manager.GameElement;

/**
 * @说明 玩家子弹类，本类的实体对象是由玩家对象调用和创建
 */
public class PlayFile extends ElementObj {
	// 发射者标识
	public static final int SHOOTER_P1 = 1;
	public static final int SHOOTER_P2 = 2;
	public static final int SHOOTER_ENEMY = 3;

	//保留原有的 shooterId
	private int shooterId;

	// 记录具体的发射者对象（比如具体的 P1 坦克对象）
	private Object shooter;

	// 子弹存活帧数（用于出生后的无敌时间）
	private int lifeTime = 0;

	public int getShooterId() {
		return shooterId;
	}
	public void setShooterId(int shooterId) {
		this.shooterId = shooterId;
	}

	// 新增 Getter 和 Setter
	public Object getShooter() {
		return shooter;
	}
	public void setShooter(Object shooter) {
		this.shooter = shooter;
	}

	public int getLifeTime() {
		return lifeTime;
	}

	private int attack; // 攻击力
	private int moveNum = 3; // 移动速度值
	private String fx = "up";

	public PlayFile() {} // 空的构造方法

	@Override
	public ElementObj createElement(String str) {
		PlayFile bullet = new PlayFile();
		String[] split = str.split(",");
		for (String str1 : split) {
			String[] split2 = str1.split(":");
			switch (split2[0]) {
				case "x": bullet.setX(Integer.parseInt(split2[1])); break;
				case "y": bullet.setY(Integer.parseInt(split2[1])); break;
				case "f": bullet.fx = split2[1]; break;
			}
		}
		bullet.setW(10);
		bullet.setH(10);
		return bullet;
	}

	@Override
	public void showElement(Graphics g) {
		if (this.isDie()) {
			return;
		}
		g.setColor(Color.red);
		g.fillOval(this.getX(), this.getY(), this.getW(), this.getH());
	}

	@Override
	protected void move() {
		// 每移动一次，存活帧数 +1
		this.lifeTime++;

		switch (this.fx) {
			case "up": this.setY(this.getY() - this.moveNum); break;
			case "left": this.setX(this.getX() - this.moveNum); break;
			case "right": this.setX(this.getX() + this.moveNum); break;
			case "down": this.setY(this.getY() + this.moveNum); break;
		}

		// 出边界销毁
		if (this.getX() < 0 || this.getX() > 800 || this.getY() < 0 || this.getY() > 600) {
			this.setDie(true);
			this.setLive(false);
			return;
		}
		if (this.fx == null) {
			this.fx = "up";
		}
	}
}



