package com.tedu.element;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import com.tedu.manager.GameLoad;

public class Wall extends ElementObj {
    // true=墙体完整可阻挡；false=被子弹打碎，可通行
    private boolean alive = true;

    private String wallType;
    public void setWallType(String wallType){
        this.wallType = wallType;
    }

    public boolean isAlive() {
        return alive;
    }
    // 被子弹击中后调用，墙体破碎
    public void breakWall(){
        this.alive = false;
    }

    @Override
    public ElementObj createElement(String str) {
        Wall wall = new Wall();
        String[] arr = str.split(",");
        String wallType = arr[0];
        int x = Integer.parseInt(arr[1]);
        int y = Integer.parseInt(arr[2]);
        wall.setWallType(wallType);
        ImageIcon icon = GameLoad.imgMap.get(wallType);
        wall.setX(x);
        wall.setY(y);
        wall.setW(icon.getIconWidth());
        wall.setH(icon.getIconHeight());
        wall.setIcon(icon);
        wall.alive = true;
        return wall;
    }

    @Override
    public void showElement(Graphics g) {
        if(!alive) return; // 破碎墙体不绘制，无阻挡
        g.drawImage(getIcon().getImage(), getX(), getY(), getW(), getH(), null);
    }

    @Override
    public void move() {} // 墙体固定不动
    @Override
    public void keyClick(boolean bl, int key) {}
    @Override
    protected void updateImage() {}
    @Override
    public void add(long gameTime) {}
}