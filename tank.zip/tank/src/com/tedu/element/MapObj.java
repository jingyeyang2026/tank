package com.tedu.element;

import com.tedu.manager.GameLoad;

import java.awt.*;

import javax.swing.ImageIcon;

public class MapObj extends ElementObj{
//	墙需要血量	
	private int hp;
	private String name;//墙的type  也可以使用枚举
	
	@Override
	public void showElement(Graphics g) {
		if(this.getIcon() == null) {
			// 贴图缺失绘制纯色方块占位
			g.setColor(Color.GRAY);
			g.fillRect(getX(), getY(), getW(), getH());
			return;
		}
		g.drawImage(this.getIcon().getImage(),
				this.getX(), this.getY(),
				this.getW(),this.getH(),null);
	}
	
	@Override   // 如果可以传入   墙类型,x,y
	public ElementObj createElement(String str) {
		MapObj map = new MapObj();

		System.out.println(str); // 名称,x,y

		String []arr=str.split(",");
		String imgKey = arr[0];
		int x=Integer.parseInt(arr[1]);
		int y=Integer.parseInt(arr[2]);
		// 从全局缓存读取贴图标识
		ImageIcon icon= GameLoad.imgMap.get(imgKey);
//		先写一个假图片再说
//		ImageIcon icon=null;
		// 容错，贴图不存在直接返回null，不中断加载
		if(icon == null){
			System.err.println("墙体贴图"+imgKey+"缺失，使用空白20*20占位");
			map.setW(20);
			map.setH(20);
			map.setIcon(null);
		}else{
			map.setW(icon.getIconWidth());
			map.setH(icon.getIconHeight());
			map.setIcon(icon);
		}
		switch(imgKey) { //设置图片信息 图片还未加载到内存中

		case "IRON":
			//icon=new ImageIcon("image/wall/iron.png");
					map.hp=4;
					map.name="IRON";
					break;
			default:
				map.hp=1;
				break;
		}


		map.setX(x);
		map.setY(y);
		return map;
	}
	@Override  //说明 这个设置扣血等的方法 需要自己思考重新编写。
		public void setLive(boolean live) {
//			被调用一次 就减少一次血。
			if("IRON".equals(name)) {// 水泥墙需要4下
				this.hp--;
				if(this.hp >0) {
					return;
				}
			}
			super.setLive(live);
		}
	
	
}




