play=com.tedu.element.Play
file=com.tedu.element.PlayFile
enemy=com.tedu.element.Enemy
wall=com.tedu.element.Wall
map=com.tedu.element.MapObj