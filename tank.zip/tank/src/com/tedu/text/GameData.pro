left=image/tank/play1/player1_left.png
down=image/tank/play1/player1_down.png
right=image/tank/play1/player1_right.png
up=image/tank/play1/player1_up.png


left2=image/tank/play2/player2_left.png
down2=image/tank/play2/player2_down.png
right2=image/tank/play2/player2_right.png
up2=image/tank/play2/player2_up.png

left3=image/tank/bot/bot_left.png
down3=image/tank/bot/bot_down.png
right3=image/tank/bot/bot_right.png
up3=image/tank/bot/bot_up.png

die=image/boom/boom.png

GRASS=image/wall/grass.png
BRICK=image/wall/brick.png
RIVER=image/wall/river.png
IRON=image/wall/iron.png