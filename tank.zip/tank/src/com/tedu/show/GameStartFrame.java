package com.tedu.show;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.MediaTracker;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import com.tedu.controller.GameListener;
import com.tedu.controller.GameThread;
import com.tedu.manager.ElementManager;
import com.tedu.manager.GameWindowConfig;

/**
 * 游戏启动菜单窗口，程序打开默认加载此页面
 * 背景：固定全屏图片
 * 按钮：单人游戏、双人游戏、操作指南
 */
public class GameStartFrame extends JFrame implements ActionListener {
    // 首页菜单面板
    private JPanel panelMenu;
    // 关卡选择面板
    private JPanel panelLevel;

    // 三个功能按钮
    private JButton btnSingle;
    private JButton btnDouble;
    private JButton btnGuide;
    // 游戏核心窗口（菜单点击后切换到游戏界面）
    private GameJFrame gameFrame;
    // 操作指南弹窗
    private GameGuideDialog guideDialog;

    // 关卡页面组件
    private JComboBox<Integer> levelBox;
    private JButton btnFire;
    private JButton btnBack;

    // 游戏窗口依赖组件

    private GameListener listener;
    private GameThread gameThread;

    private final GameWindowConfig windowCfg = GameWindowConfig.getInstance();

    private static GameStartFrame instance;



    private final int STANDARD_W = windowCfg.getGameWindowWidth();
    private final int STANDARD_H = windowCfg.getGameWindowHeight();


    private GameStartFrame() {
        initFrame();
        // 先创建控制器
        listener = new GameListener();
        gameThread = new GameThread();

        // 单独实例化GameJFrame，捕获异常
        GameJFrame tempFrame = null;
        try {
            tempFrame = new GameJFrame();
            System.out.println("GameJFrame实例创建成功");
        } catch (Exception e) {
            System.err.println("创建GameJFrame失败");
            e.printStackTrace();
        }
        // 赋值给全局变量
        this.gameFrame = tempFrame;

        // 判空再注入，杜绝空指针调用方法
        if (this.gameFrame != null) {
            gameFrame.setKeyListener(listener);
            gameFrame.setThead(gameThread);
        }

        initComponent();
        ImageIcon testImg = new ImageIcon("image/login_background.png");
        if(testImg == null || testImg.getIconWidth() <= 0){
            System.err.println("找不到背景图资源：image/login_background.png");
        }else{
            System.out.println("背景图资源读取成功" );
        }
        //setVisible(true);
    }

    // 窗口基础配置
    private void initFrame() {
        setTitle("坦克大战-启动菜单");
        int menuW = windowCfg.getDefaultWidth();
        int menuH = windowCfg.getGameWindowHeight();
        setSize(menuW, menuH); // 和游戏画布尺寸保持统一
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // 窗口居中
        setLayout(null); // 绝对布局，放置按钮

    }

    // 初始化背景面板+三个按钮
    private void initComponent() {
        int menuW = windowCfg.getDefaultWidth();
        int menuH = windowCfg.getGameWindowHeight();
        // 底层固定背景面板
        JPanel bgPanel = new JPanel(){
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                // 先填充兜底底色，防止空白
                g.setColor(Color.DARK_GRAY);
                g.fillRect(0,0,menuW,menuH);


                ImageIcon bgImg = new ImageIcon("image/login_background.png");

                if(bgImg != null && bgImg.getIconWidth()>0){

                    // 判断图片加载完整

                        g.drawImage(bgImg.getImage(),0,0,menuW,menuH,null);
                        return;

                }
                // 图片缺失时文字提示
                g.setColor(Color.WHITE);
                g.drawString("背景图读取失败：项目根目录image/login_background.png", 260, 300);
            }
        };
        bgPanel.setBounds(0,0,menuW,menuH);
        bgPanel.setPreferredSize(new Dimension(menuW, menuH));
        bgPanel.setLayout(null);
        this.add(bgPanel);

        panelMenu = new JPanel(null);
        panelMenu.setOpaque(false); // 透明，透出底层背景图
        panelMenu.setBounds(0,0,menuW,menuH);

        btnSingle = new JButton("单人游戏");
        btnSingle.setBounds(350,200,200,50);
        btnSingle.addActionListener(this);

        btnDouble = new JButton("双人游戏");
        btnDouble.setBounds(350,280,200,50);
        btnDouble.addActionListener(this);

        btnGuide = new JButton("操作指南");
        btnGuide.setBounds(350,360,200,50);
        btnGuide.addActionListener(this);

        panelMenu.add(btnSingle);
        panelMenu.add(btnDouble);
        panelMenu.add(btnGuide);
        bgPanel.add(panelMenu);


        panelLevel = new JPanel();
        panelLevel.setOpaque(false); // 透明，共用底层背景
        panelLevel.setLayout(new GridLayout(4,1,10,10));
        panelLevel.setBorder(BorderFactory.createEmptyBorder(200,300,200,300));
        panelLevel.setBounds(0,0,menuW,menuH);
        panelLevel.setVisible(false); // 默认不显示

        // 下拉关卡选择框
        Integer[] levelArr = new Integer[10];
        for(int i=0;i<10;i++) levelArr[i] = i+1;
        levelBox = new JComboBox<>(levelArr);
        levelBox.setSelectedItem(1);
        panelLevel.add(new JLabel("选择关卡(1~10)："));
        panelLevel.add(levelBox);

        // fire开始按钮
        btnFire = new JButton("fire");
        btnFire.addActionListener(this);
        panelLevel.add(btnFire);

        // 返回按钮
        btnBack = new JButton("Return");
        btnBack.addActionListener(this);
        panelLevel.add(btnBack);

        bgPanel.add(panelLevel);

        // 初始化指南弹窗
        guideDialog = new GameGuideDialog(this);
        //gameFrame = new GameJFrame();
    }

    // 按钮点击事件分发
    @Override
    public void actionPerformed(ActionEvent e) {
        // 首页【单人游戏】
        if(e.getSource() == btnSingle){
            ElementManager.setPlayerCount(1);
            System.out.println("单人模式，玩家数量=1");
            // 隐藏首页面板，显示关卡面板，背景图不变
            panelMenu.setVisible(false);
            panelLevel.setVisible(true);
        }
        // 首页【双人游戏】
        else if(e.getSource() == btnDouble){
            ElementManager.setPlayerCount(2);
            System.out.println("双人模式，玩家数量=2");
            panelMenu.setVisible(false);
            panelLevel.setVisible(true);
        }
        // 首页【操作指南】
        else if(e.getSource() == btnGuide){
            guideDialog.setVisible(true);
        }
        // 关卡页面【fire】
        else if(e.getSource() == btnFire){
            int selectLevel = (Integer) levelBox.getSelectedItem();
            ElementManager.setNowLevel(selectLevel);
            System.out.println("==== fire按钮触发，准备启动游戏，关卡编号："+selectLevel+" ====");
            if(gameFrame == null){
                JOptionPane.showMessageDialog(this,"游戏窗口实例创建失败，无法启动游戏！","启动异常",JOptionPane.ERROR_MESSAGE);
                return;
            }

            this.switchToGame();
        }
        // 关卡页面【返回】
        else if(e.getSource() == btnBack){
            // 隐藏关卡面板，恢复首页面板，背景图完全不变
            panelLevel.setVisible(false);
            panelMenu.setVisible(true);
        }
    }


    public static GameStartFrame getInstance(){
        if(instance == null) {
            instance = new GameStartFrame();
            instance.setVisible(true);
        }
        return instance;
    }


    // 切换到游戏画面，复用当前窗口，不新开、不销毁窗口
    public void switchToGame() {

        if(gameThread != null){
            gameThread.stopThread();
            try {
                Thread.sleep(80);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // 清空窗口所有原有首页组件
        this.getContentPane().removeAll();
        // 获取游戏画布
        GameMainJPanel gamePanel = gameFrame.getGamePanel();
        int w = windowCfg.getGameWindowWidth();
        int h = windowCfg.getGameWindowHeight();
        gamePanel.setBounds(0, 0, w, h);
        gamePanel.createBackButton();
        // 画布铺满整个窗口
        this.getContentPane().add(gamePanel);
        // 刷新界面
        this.revalidate();
        this.repaint();

        listener = new GameListener();
        this.addKeyListener(listener);
        this.setFocusable(true);
        this.requestFocusInWindow();





        // 启动渲染、逻辑线程

        gameThread = new GameThread();
        gameFrame.setThead(gameThread);
        Thread renderThread = new Thread(gamePanel);
        renderThread.start();
        Thread logicThread = new Thread(gameThread);
        logicThread.start();


    }

    // 从游戏切回首页菜单
    public void switchToMenu() {
        if(gameThread != null){
            gameThread.stopThread();
            try {
                Thread.sleep(60);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // 清空窗口游戏画布
        this.getContentPane().removeAll();
        // 重新加载首页背景、按钮面板
        initComponent();
        this.revalidate();
        this.repaint();
        this.removeKeyListener(listener);

        // switchToMenu方法内添加
        GameMainJPanel panel = gameFrame.getGamePanel();
        panel.stopRender();



    }



}
