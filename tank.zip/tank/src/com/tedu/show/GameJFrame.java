package com.tedu.show;

import com.tedu.controller.GameListener;
import com.tedu.controller.GameThread;
import com.tedu.manager.ElementManager;
import com.tedu.manager.GameWindowConfig;

import javax.swing.*;
import java.awt.*;

public class GameJFrame {
	// 顶层窗口
	private JFrame gameWindow;
	// 游戏绘图画板
	private GameMainJPanel gamePanel;
	// 键盘输入监听
	private GameListener keyListener;
	// 游戏逻辑加载/帧循环线程
	private GameThread gameLogicThread;
//   全局窗口配置单例
	private final GameWindowConfig windowCfg = GameWindowConfig.getInstance();

	public GameJFrame() {
		initWindow();
	}

	// 窗口基础初始化
	private void initWindow() {
		gameWindow = new JFrame("坦克大战正式游戏");
		int initWidth = windowCfg.getDefaultWidth();
		int fixedHeight = windowCfg.getGameWindowHeight();
		gameWindow.setSize(initWidth, fixedHeight);
		gameWindow.setLocationRelativeTo(null);
		gameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameWindow.setLayout(null);

		// 初始化绘图画板
		gamePanel = new GameMainJPanel();
		gamePanel.setBounds(0, 0, initWidth, fixedHeight);
		// 将画布加入窗口
		gameWindow.add(gamePanel);
	}

	// 注入键盘监听
	public void setKeyListener(GameListener listener) {
		this.keyListener = listener;

		// 窗口必须可聚焦才能接收按键
		if(gameWindow!=null){
			gameWindow.setFocusable(true);
			gameWindow.addKeyListener(keyListener);
		}

	}

	// 注入游戏逻辑线程
	public void setThead(GameThread thread) {
		this.gameLogicThread = thread;
	}

	// 启动游戏窗口总入口（fire按钮调用）
	public void start() {
		int winW = windowCfg.getGameWindowWidth();
		int winH = windowCfg.getGameWindowHeight();
		System.out.println("当前计算窗口宽度："+winW);
		if(gameWindow == null || gamePanel == null){
			JOptionPane.showMessageDialog(null,"游戏窗口/画布初始化失败，无法启动游戏","启动错误",JOptionPane.ERROR_MESSAGE);
			return;
		}
		gameWindow.setSize(winW, winH);
		gameWindow.setResizable(false);
		gamePanel.setPreferredSize(new Dimension(winW, winH));
		gamePanel.setBounds(0, 0, winW, winH);
		gameWindow.getContentPane().setPreferredSize(new Dimension(winW,winH));
		gameWindow.pack();
		gameWindow.getContentPane().revalidate();
		gameWindow.getContentPane().repaint();

		// 窗口可见
		//gameWindow.setVisible(true);
		gameWindow.requestFocusInWindow(); // 主动获取焦点，键盘监听生效
		// 启动画布渲染刷新线程（缺失会全程空白，无画面刷新）
		Thread renderThread = new Thread(gamePanel);
		renderThread.start();
		// 启动游戏逻辑线程：加载地图、玩家、帧循环更新
		if(gameLogicThread != null){
			Thread logicThread = new Thread(gameLogicThread);
			logicThread.start();
		}

	}

	public GameMainJPanel getGamePanel(){
		return this.gamePanel;
	}


}
