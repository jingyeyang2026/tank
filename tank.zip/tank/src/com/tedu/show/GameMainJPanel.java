package com.tedu.show;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.*;

import com.tedu.controller.GameThread;
import com.tedu.element.ElementObj;
import com.tedu.element.Play;
import com.tedu.game.GameStart;
import com.tedu.manager.ElementManager;
import com.tedu.manager.GameElement;
import com.tedu.manager.GameWindowConfig;

/**
 * @说明 游戏的主要面板
 *
 * @功能说明 主要进行元素的显示，同时进行界面的刷新(多线程)
 * 
 * @题外话 java开发实现思考的应该是：做继承或者是接口实现
 * 
 * @多线程刷新 1.本类实现线程接口
 *             2.本类中定义一个内部类来实现
 */
public class GameMainJPanel extends JPanel implements Runnable{
//	联动管理器
	private ElementManager em;
	private final GameWindowConfig windowCfg = GameWindowConfig.getInstance();
//	渲染刷新间隔常量
	private static final int RENDER_SLEEP = 10;
	private JButton btnBack;

	private GameThread gameThread;
	private final int MARGIN = 15;

	private volatile boolean renderAlive = true;


	public GameMainJPanel() {
		setDoubleBuffered(true); // 开启双缓冲
		setLayout(null);
		//initBtn();
		em = ElementManager.getManager();
	}


	public void createBackButton(){
		// 先移除旧按钮防止重复叠加
		if(btnBack != null){
			this.remove(btnBack);
		}
		btnBack = new JButton("返回首页");
		btnBack.setSize(100, 36);
		btnBack.setLocation(780, 450);
		btnBack.setFont(new Font("微软雅黑", Font.PLAIN, 14));
		btnBack.setBackground(new Color(220, 50, 50));
		btnBack.setForeground(Color.ORANGE);

		btnBack.addActionListener((ActionEvent e) -> {
			if(gameThread != null){
				gameThread.stopThread();
				try {
					Thread.sleep(60);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
			}
			//ElementManager.getManager().clearAllElement();
			GameStartFrame root = GameStartFrame.getInstance();
			root.switchToMenu();
		});
		this.add(btnBack);
	}



	// 外部窗口传入正在运行的GameThread线程对象
	public void setGameThread(GameThread gameThread) {
		this.gameThread = gameThread;
	}

	/**
	 * paint方法是进行绘画元素。
	 * 绘画时是有固定的顺序，先绘画的图片会在底层，后绘画的图片会覆盖先绘画的
	 * 约定：本方法只执行一次,想实时刷新需要使用 多线程
	 */


	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);


		int winW = windowCfg.getGameWindowWidth();
		int winH = windowCfg.getGameWindowHeight();
		// 填充黑色背景
		g.setColor(Color.BLACK);
		g.fillRect(0,0,winW,winH);
		if(em == null) return;
		Map<GameElement, List<ElementObj>> all = em.getGameElements();
		for(GameElement ge:GameElement.values()) {
			List<ElementObj> list = all.get(ge);
			if(list == null || list.size() == 0) continue;
			for(int i=0;i<list.size();i++) {
				ElementObj obj=list.get(i);
				obj.showElement(g);
			}
		}
		int nowLevel = ElementManager.getNowLevel();
		String levelText = "第" + nowLevel + "关";
		g.setFont(new Font("微软雅黑", Font.BOLD, 22));
		g.setColor(Color.YELLOW);
		FontMetrics fm = g.getFontMetrics();

		int textWidth = fm.stringWidth(levelText);
		int textX = this.getWidth() - textWidth - MARGIN;
		int textY = MARGIN + 25;
		g.drawString(levelText, textX, textY);
	}




	@Override
	public void run() {  //接口实现
		while(renderAlive) {
//			System.out.println("多线程运动");
			repaint();
//			一般情况下，多线程都会使用一个休眠,控制速度
			try {
				Thread.sleep(RENDER_SLEEP); //休眠10毫秒 1秒刷新20次
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}
	}
	public void stopRender(){
		this.renderAlive = false;
	}
	
}











