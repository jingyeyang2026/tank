package com.tedu.show;

import javax.swing.*;
import java.awt.*;

/**
 * 操作指南弹窗，点击按钮弹出，关闭后返回菜单页面
 * 预留文本展示区域，后续自行填充说明文字
 */
public class GameGuideDialog extends JDialog {
    private JTextArea textArea;
//    弹窗尺寸常量
    private static final int DIALOG_WIDTH = 500;
    private static final int DIALOG_HEIGHT = 400;

    public GameGuideDialog(JFrame parent) {
        super(parent,"操作指南",true); // 模态弹窗，必须关闭才能操作菜单
        initDialog();
        initTextArea();
        initCloseBtn();
    }

    // 弹窗基础尺寸配置
    private void initDialog() {
        setSize(DIALOG_WIDTH, DIALOG_HEIGHT);
        if(getOwner() != null){
            setLocationRelativeTo(getOwner()); // 弹窗相对菜单窗口居中
        }else{
            setLocationRelativeTo(null);
        }
        setLayout(new BorderLayout());
    }

    // 预留文本区域
    private void initTextArea() {
        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setEditable(false); // 禁止用户编辑

        textArea.setText(
                "玩家1操作：上下左右方向键移动，空格键发射子弹\n" +
                "玩家2操作：W上 A左 S下 D右，G键发射子弹");
        JScrollPane scrollPane = new JScrollPane(textArea);
        this.add(scrollPane,BorderLayout.CENTER);
    }

    // 关闭按钮
    private void initCloseBtn() {
        JButton btnClose = new JButton("关闭");
        btnClose.addActionListener(e -> this.setVisible(false));
        JPanel btnPanel = new JPanel();
        btnPanel.add(btnClose);
        this.add(btnPanel,BorderLayout.SOUTH);
    }
}
