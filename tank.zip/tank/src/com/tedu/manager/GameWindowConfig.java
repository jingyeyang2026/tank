package com.tedu.manager;

/**
 * 全局游戏窗体尺寸统一管理类
 * 所有板块获取窗口宽高只能调用本类get方法，禁止硬编码数字
 */
public class GameWindowConfig {

    // 游戏画布固定高度，全程不变
    public static final int FIX_WINDOW_HEIGHT = 600;
    // 窗口最小兜底宽度，防止地图加载失败出现极窄窗口
    public static final int MIN_WINDOW_WIDTH = 770;
    // 程序初始默认窗口宽度（菜单/未加载地图时使用）
    public static final int DEFAULT_WINDOW_WIDTH = 900;


    // 根据地图墙体计算出的实际游戏宽度
    private int dynamicGameWidth;


    private static GameWindowConfig instance;

    // 私有构造，禁止外部new
    private GameWindowConfig() {
        // 初始化默认宽度
        this.dynamicGameWidth = DEFAULT_WINDOW_WIDTH;
    }

    // 获取全局唯一实例
    public static synchronized GameWindowConfig getInstance() {
        if (instance == null) {
            instance = new GameWindowConfig();
        }
        return instance;
    }


    /**
     * 获取当前生效的窗口总宽度（已做最小值兜底）
     * */
    public int getGameWindowWidth() {
        // 自动兜底，永远不会小于MIN_WINDOW_WIDTH
        return Math.max(dynamicGameWidth, MIN_WINDOW_WIDTH);
    }

    /**
     * 获取固定窗口高度
     * */
    public int getGameWindowHeight() {
        return FIX_WINDOW_HEIGHT;
    }

    /**
     * 获取初始默认宽度（菜单界面使用）
     * */
    public int getDefaultWidth() {
        return DEFAULT_WINDOW_WIDTH;
    }


    /**
     * GameLoad.MapLoad 地图加载完成后调用，更新地图计算宽度
     * @param calculateWidth 地图墙体计算出的原始宽度
     */
    public void updateDynamicWidth(int calculateWidth) {
        this.dynamicGameWidth = calculateWidth;
        // 内部自动兜底，外部无需处理
        System.out.println("【窗口配置更新】原始地图宽度:" + calculateWidth
                + "，最终生效窗口宽度:" + getGameWindowWidth());
    }
}