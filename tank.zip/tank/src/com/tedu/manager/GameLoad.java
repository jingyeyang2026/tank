package com.tedu.manager;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import javax.swing.ImageIcon;
import com.tedu.element.ElementObj;
import com.tedu.element.MapObj;
import com.tedu.element.Play;
import com.tedu.element.Wall;
import com.tedu.element.Enemy;
import java.util.Random;

/**
 * @说明 加载器(工具：用户读取配置文件的工具)工具类,大多提供的是 static方法
 * @author renjj
 */
public class GameLoad {
	// 得到资源管理器
	private static ElementManager em = ElementManager.getManager();
	// 全局窗口尺寸配置单例
	private static GameWindowConfig windowCfg = GameWindowConfig.getInstance();
	// 图片集合 使用map来进行存储
	public static Map<String, ImageIcon> imgMap = new HashMap<>();
	public static Map<String, List<ImageIcon>> imgMaps;
	// 读取配置文件工具
	private static Properties pro = new Properties();

	/**
	 * @说明 传入地图id加载对应.map地图文件，所有坐标统一生成可破碎墙体Wall
	 * @param mapId 关卡编号
	 */
	public static void MapLoad(int mapId) {
		// 只提取数字，防止非法后缀
		String idStr = String.valueOf(mapId).replaceAll("[^0-9]", "");
		int realId = Integer.parseInt(idStr);
		String mapName = "com/tedu/text/" + realId + ".map";
		ClassLoader classLoader = GameLoad.class.getClassLoader();
		InputStream maps = classLoader.getResourceAsStream(mapName);
		if (maps == null) {
			System.err.println("【致命】地图文件读取失败：" + mapName);
			windowCfg.updateDynamicWidth(0);
			return;
		}
		em.setMapMaxWallX(0);
		em.setMaxXWallWidth(0);
		try {
			pro.clear();
			pro.load(maps);
			Enumeration<?> names = pro.propertyNames();
			while (names.hasMoreElements()) {
				String key = names.nextElement().toString();
				String valueStr = pro.getProperty(key);
				System.out.println(valueStr);
				String[] arrs = valueStr.split(";");
				for (int i = 0; i < arrs.length; i++) {
					String coord = arrs[i].trim();
					if (coord.isEmpty()) continue;
					String[] xyArr = coord.split(",");
					int wallX = Integer.parseInt(xyArr[0]);
					if (wallX > em.getMapMaxWallX()) {
						em.setMapMaxWallX(wallX);
						em.setMaxXWallWidth(20);
					}
					Wall wall = new Wall();
					String wallFullInfo = key + "," + coord; //拼接格式 BRICK,20,40
					ElementObj element = wall.createElement(wallFullInfo);

					if (element == null) {
						System.err.println("墙体" + key + ":" + coord + "贴图缺失，跳过渲染");
						continue;
					}
					em.addElement(element, GameElement.WALL);
					if (wallX == em.getMapMaxWallX()) {
						em.setMaxXWallWidth(element.getW());
					}
				}
			}
			maps.close();
			// 计算窗口总宽度
			int calculateTotalWidth = em.getMapMaxWallX() + em.getMaxXWallWidth();
			windowCfg.updateDynamicWidth(calculateTotalWidth);
			System.out.println("最大墙体X：" + em.getMapMaxWallX() + " 对应墙体宽：" + em.getMaxXWallWidth() + " 窗体总宽：" + windowCfg.getGameWindowWidth());
		} catch (IOException e) {
			e.printStackTrace();
		}
		// 打印数量校验
		int mapObjCount = em.getElementsByKey(GameElement.MAPS).size();
		int breakableWallCount = em.getElementsByKey(GameElement.WALL).size();
		System.out.println("无碰撞地图装饰数量：" + mapObjCount);
		System.out.println("可碰撞破碎墙体总数：" + breakableWallCount);
	}

	/**
	 * 加载全部贴图资源
	 */
	public static void loadImg() {
		String texturl = "com/tedu/text/GameData.pro";
		ClassLoader classLoader = GameLoad.class.getClassLoader();
		InputStream texts = classLoader.getResourceAsStream(texturl);
		pro.clear();
		if (texts == null) {
			System.err.println("GameData.pro资源文件读取失败！路径错误或文件不存在");
			imgMap.put("up", new ImageIcon());
			imgMap.put("up2", new ImageIcon());
			return;
		}
		try {
			pro.load(texts);
			Set<Object> set = pro.keySet();
			int count = 0;
			for (Object o : set) {
				String key = o.toString();

				String relativePath = pro.getProperty(key);
				String projectRoot = System.getProperty("user.dir");
				String fullImgPath = projectRoot + "/" + relativePath;
				ImageIcon icon = new ImageIcon(fullImgPath);
				imgMap.put(key, icon);
				System.out.println("加载贴图标识：" + key + " 路径：" + fullImgPath);
				count++;
			}
			texts.close();
			System.out.println("贴图加载完成，共加载 " + count + " 张");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 加载玩家坦克，支持单人/双人
	 */
	public static void loadPlay() {
		loadObj();
		int count = ElementManager.getSavePlayerCount();
		int mapW = windowCfg.getGameWindowWidth();
		// 兜底宽度
		if (mapW <= 300) {
			mapW = windowCfg.getDefaultWidth();
			System.err.println("地图宽度计算异常，使用默认宽度" + mapW);
		}
		loadPlay(count);

	}

	public static void loadPlay(int playerNum){
		loadObj();
		int mapW = windowCfg.getGameWindowWidth();
		if(mapW <= 300){
			mapW = windowCfg.getDefaultWidth();
			System.err.println("地图宽度计算异常，使用默认宽度"+mapW);
		}
		// 先清空旧玩家，防止重复叠加
		List<ElementObj> playList = ElementManager.getManager().getElementsByKey(GameElement.PLAY);
		playList.clear();
		if(playerNum == 1){
			createSinglePlay(1, "290,520,up");
		}else if(playerNum ==2){
			// 双人必须同时创建玩家1、玩家2
			createSinglePlay(1, "290,520,up");
			createSinglePlay(2, "480,520,up");
		}
		System.out.println("双人/单人玩家创建完成，当前玩家数量："+playerNum);
	}

	/**
	 * 生成单个玩家坦克
	 */
	private static void createSinglePlay(int no, String posStr) {
		ElementObj obj = getObj("play");
		if (obj == null) {
			System.err.println("反射获取Play类失败，检查obj.pro配置");
			return;
		}
		ElementObj play = obj.createElement(posStr);
		((Play) play).setPlayerNo(no);
		em.addElement(play, GameElement.PLAY);
	}

	/**
	 * 反射创建实体对象
	 */
	public static ElementObj getObj(String str) {
		try {
			Class<?> class1 = objMap.get(str);
			if (class1 == null) {
				System.err.println("反射key[" + str + "]不存在，obj.pro未配置");
				return null;
			}
			Object newInstance = class1.newInstance();
			if (newInstance instanceof ElementObj) {
				return (ElementObj) newInstance;
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Map<String, Class<?>> objMap = new HashMap<>();

	/**
	 * 加载实体反射配置 obj.pro
	 */
	public static void loadObj() {
		String texturl = "com/tedu/text/obj.pro";
		ClassLoader classLoader = GameLoad.class.getClassLoader();
		InputStream texts = classLoader.getResourceAsStream(texturl);
		pro.clear();
		if (texts == null) {
			System.err.println("obj.pro资源读取失败，路径：" + texturl);
			return;
		}
		try {
			pro.load(texts);
			Set<Object> set = pro.keySet();
			for (Object o : set) {
				String classUrl = pro.getProperty(o.toString());
				Class<?> forName = Class.forName(classUrl);
				objMap.put(o.toString(), forName);
			}
			texts.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 加载敌方坦克
	 * 修改说明：
	 * 1. 移除了不存在的 enemy.turnTo() 方法调用。
	 * 2. 改为直接设置敌人的坐标和方向。
	 * 3. 根据方向从 GameData.pro 加载对应的贴图 (up3, down3, left3, right3)。
	 */

	public static void loadEnemy() {
		Random random = new Random();
		int enemyCount = 2; // 每次生成2个敌人
		int tankSize = 40; // 坦克尺寸
		int windowMaxWidth = GameWindowConfig.getInstance().getGameWindowWidth();
		int safeYLimit = 520; // 安全Y轴上限

		for (int i = 0; i < enemyCount; i++) {
			// 1. 随机生成坐标
			int randomX = random.nextInt(windowMaxWidth - tankSize);
			int randomY = random.nextInt(safeYLimit - tankSize);

			// 2. 创建敌人对象并设置基本属性
			Enemy enemy = new Enemy();
			enemy.setX(randomX);
			enemy.setY(randomY);
			enemy.setW(tankSize);
			enemy.setH(tankSize);
			enemy.setLive(true);
			enemy.setDie(false);

			// 直接调用 randomDir() 来初始化方向和贴图
			// 这会自动设置 up/down/left/right 变量并加载对应的图片
			enemy.randomDir();

			//  将敌人添加到游戏管理器中
			ElementManager.getManager().addElement(enemy, GameElement.ENEMY);

			//  打印日志验证
			System.out.println("【敌人出生监控】生成坐标: X=" + randomX + ", Y=" + randomY);
			System.out.println("【敌人出生监控】实际对象坐标: X=" + enemy.getX() + ", Y=" + enemy.getY());
			System.out.println("【敌人出生监控】存活状态: " + enemy.isLive() + ", 贴图是否为空: " + (enemy.getIcon() == null));
		}
	}




}




