package com.tedu.manager;
import com.tedu.element.ElementObj;
import com.tedu.element.Wall;
import java.util.List;

public class CollisionChecker {
    private static final CollisionChecker INSTANCE = new CollisionChecker();
    private List<ElementObj> wallList;
    private CollisionChecker(){}
    public static CollisionChecker getInstance(){return INSTANCE;}

    public void refreshWallData(List<ElementObj> walls){
        this.wallList = walls;
        // 打印当前传入碰撞工具的墙体总数
        System.out.println("碰撞工具接收墙体："+(walls==null?0:walls.size()));
    }

    public boolean canMoveUp(ElementObj tank){
        int newY = tank.getY() - 1;
        boolean hit = checkRect(tank.getX(), newY, tank.getW(), tank.getH());
        if(hit) System.out.println("向上移动撞墙，禁止移动");
        return !hit;
    }
    public boolean canMoveDown(ElementObj tank){
        int newY = tank.getY() + 1;
        boolean hit = checkRect(tank.getX(), newY, tank.getW(), tank.getH());
        if(hit) System.out.println("向下移动撞墙，禁止移动");
        return !hit;
    }
    public boolean canMoveLeft(ElementObj tank){
        int newX = tank.getX() - 1;
        boolean hit = checkRect(newX, tank.getY(), tank.getW(), tank.getH());
        if(hit) System.out.println("向左移动撞墙，禁止移动");
        return !hit;
    }
    public boolean canMoveRight(ElementObj tank){
        int newX = tank.getX() + 1;
        boolean hit = checkRect(newX, tank.getY(), tank.getW(), tank.getH());
        if(hit) System.out.println("向右移动撞墙，禁止移动");
        return !hit;
    }

    // 标准矩形相交检测
    private boolean checkRect(int tX,int tY,int tW,int tH){
        if(wallList == null || wallList.isEmpty()){
            System.out.println("碰撞工具无墙体数据！");
            return false;
        }
        for(ElementObj obj : wallList){
            if(!obj.isLive()) continue;

            int wX = obj.getX();
            int wY = obj.getY();
            int wW = obj.getW();
            int wH = obj.getH();
            // 矩形相交公式
            boolean intersect = tX < wX + wW && tX + tW > wX && tY < wY + wH && tY + tH > wY;
            if(intersect){
                System.out.println("矩形相交：坦克("+tX+","+tY+") 墙体("+wX+","+wY+")");
                return true;
            }
        }
        return false;
    }
}